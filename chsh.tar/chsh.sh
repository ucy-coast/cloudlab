#!/bin/sh

sudo usermod -s /bin/bash `whoami`
