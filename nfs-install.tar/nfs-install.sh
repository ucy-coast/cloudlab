#!/bin/bash

EXPORT_PATH=$1

sudo apt-get update
sudo apt-get install -y nfs-kernel-server 

EXPORT_CMD="$EXPORT_PATH *(rw,nohide,insecure,no_subtree_check,sync)" 

grep -qxF "$EXPORT_CMD" /etc/exports || echo "$EXPORT_CMD" | sudo tee -a /etc/exports

sudo service nfs-kernel-server restart
